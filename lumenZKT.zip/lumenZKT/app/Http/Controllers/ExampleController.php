<?php

namespace App\Http\Controllers;
use DB;
use PDO;

class ExampleController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function index()
    {
      $dbName = $_SERVER['DOCUMENT_ROOT']."\db\att2000.mdb";

      try{

        // connection with .mdb file
        $mdbConn = new PDO("odbc:Driver={Microsoft Access Driver (*.mdb)}; DBq=$dbName;Uid=Admin;Pwd=;");
        // connection with local mySql
        $users = DB::connection('')->getPdo();

        $users->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);



        $mdbstmt = $mdbConn->prepare("SELECT TOP 5 * FROM CHECKINOUT where IsProcess=1");
        $mdbstmt->execute();
        // exit();


        foreach ($mdbstmt->fetchAll() as $key => $row) {


          $stmt = $users->prepare("INSERT INTO checkinout (USERID,CHECKTIME,CHECKTYPE,VERIFYCODE,SENSORID,Memoinfo,WorkCode,sn,UserExtFmt,IsProcess) VALUES (:USERID,:CHECKTIME,:CHECKTYPE,:VERIFYCODE,:SENSORID,:Memoinfo,:WorkCode,:sn,:UserExtFmt,:IsProcess)");         

        // Bind Param
          $stmt->bindParam(':USERID', $USERID);
          $stmt->bindParam(':CHECKTIME', $CHECKTIME);
          $stmt->bindParam(':CHECKTYPE', $CHECKTYPE);
          $stmt->bindParam(':VERIFYCODE', $VERIFYCODE);
          $stmt->bindParam(':SENSORID', $SENSORID);
          $stmt->bindParam(':Memoinfo', $Memoinfo);
          $stmt->bindParam(':WorkCode', $WorkCode);
          $stmt->bindParam(':sn', $sn);
          $stmt->bindParam(':UserExtFmt', $UserExtFmt);
          $stmt->bindParam(':IsProcess', $IsProcess);

          

          $USERID       =$row['USERID'];
          $CHECKTIME    =$row['CHECKTIME'];
          $CHECKTYPE    =$row['CHECKTYPE'];
          $VERIFYCODE   =$row['VERIFYCODE'];
          $SENSORID     =$row['SENSORID'];
          $Memoinfo     =$row['Memoinfo'];
          $WorkCode     =$row['WorkCode'];
          $sn           =$row['sn'];
          $UserExtFmt   =$row['UserExtFmt'];
          $IsProcess    =$row['IsProcess'];
          $result       = $stmt->execute();

          //$lastID = cubrid_insert_id();
          $mdbstmt = $mdbConn->prepare("UPDATE CHECKINOUT SET IsProcess = 0 where USERID = LAST_INSERT_ID() ");
          $mdbstmt->execute();

        }
        print_r((["status"=>"success","message"=>"Data Successfully Inserted","data"=>$result]));

      }catch(PDOException $e) {         
        echo $e->getMessage()."\n"; 
        exit; 
      }
    }
  }
