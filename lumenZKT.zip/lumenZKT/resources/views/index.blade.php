<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
</head>
<body>
	<table>
		@foreach($users as $rows)
		<tr>{{ $rows->USERID }}</tr>
		@endforeach
	</table>
</body>
</html>