<?php
namespace config;
class PDO{    
public static $pdo;    
public static function connect()    {            
$driver = 'mysql';            
$host = 'localhost';            
$database = 'zkt_agent';            
$username = 'root';            
$password = '';            
self::$pdo = new \PDO("{$driver}:host={$host};dbname={$database}", "{$username}", "{$password}");//local            
self::$pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);        
return self::$pdo;    
}