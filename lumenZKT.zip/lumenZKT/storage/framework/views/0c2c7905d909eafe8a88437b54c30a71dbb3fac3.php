<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
</head>
<body>
	<table>
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr><?php echo e($rows->USERID); ?></tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</body>
</html>